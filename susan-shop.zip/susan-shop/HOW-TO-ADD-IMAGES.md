# Hướng Dẫn Thêm Hình Ảnh Sản Phẩm

## 📸 Cách Thêm Ảnh Cho Sản Phẩm

### Bước 1: Thêm File Ảnh Vào Thư Mục `images/`

1. Copy file ảnh bạn muốn sử dụng vào thư mục `susan-shop/images/`
2. Đảm bảo tên file không có khoảng trắng (dùng dấu gạch ngang hoặc dấu gạch dưới)
3. Khuyến nghị sử dụng định dạng `.jpg` hoặc `.png`
4. Kích thước ảnh nên từ 400x400px trở lên để đảm bảo chất lượng

**Ví dụ:**

```
susan-shop/
  └── images/
      ├── macbook.jpg
      ├── iphone.jpg
      ├── laptop-dell.jpg
      └── tshirt-blue.jpg
```

### Bước 2: Cập Nhật File `data/products.json`

Mở file `susan-shop/data/products.json` và cập nhật trường `"image"`:

**Trước:**

```json
{
  "id": 1,
  "name": "MacBook Pro 16",
  "image": "images/old-name.jpg"
}
```

**Sau:**

```json
{
  "id": 1,
  "name": "MacBook Pro 16",
  "image": "images/macbook.jpg
}
```

⚠️ **Lưu ý**: Đường dẫn phải bắt đầu bằng `images/` và không có dấu `/` ở đầu

### Bước 3: Thêm Ảnh Cho Product Variants (Tùy Chọn)

Nếu sản phẩm có nhiều biến thể (variant) và bạn muốn mỗi variant có ảnh riêng:

Mở file `susan-shop/data/product-variants.json` và cập nhật:

```json
{
  "id": 1,
  "product_id": 1,
  "variant_name": "MacBook Pro 16 - Space Gray - 512GB",
  "price": 2499,
  "quantity": 15,
  "image": "images/macbook-gray.jpg"
}
```

### Bước 4: Kiểm Tra Kết Quả

1. Refresh lại trang web
2. Xem danh sách sản phẩm - ảnh sẽ hiển thị thay vì icon placeholder
3. Nếu ảnh không hiển thị, kiểm tra:
   - Đường dẫn file trong JSON có đúng không
   - File ảnh có tồn tại trong thư mục `images/` không
   - Tên file có đúng hoàn toàn (phân biệt chữ hoa/thường)

## 🔧 Cấu Trúc Hiện Tại

Website đã được cập nhật để tự động hiển thị ảnh từ trường `image` trong JSON:

### File `scripts/main.js` (Trang chủ)

```javascript
const imagePath = product.image || "images/placeholder.jpg";
productCard.innerHTML = `
    <div class="product-image">
        <img src="${imagePath}" alt="${product.name}" 
             onerror="this.src='images/placeholder.jpg'; this.onerror=null;">
    </div>
    ...
`;
```

### File `scripts/products.js` (Trang danh sách sản phẩm)

Tương tự như trên - tự động hiển thị ảnh từ trường `image`

### File `scripts/product-detail.js` (Trang chi tiết sản phẩm)

```javascript
const imagePath = product.image || "images/placeholder.jpg";
container.innerHTML = `
    <div class="product-detail-image">
        <img src="${imagePath}" alt="${product.name}" 
             onerror="this.src='images/placeholder.jpg'; this.onerror=null;">
    </div>
    ...
`;
```

## 📋 Ví Dụ Hoàn Chỉnh

### 1. Sản phẩm với ảnh duy nhất

**File JSON:**

```json
{
  "id": 9,
  "name": "New Product",
  "cate_id": 5,
  "detail": "Product description here",
  "image": "images/new-product.jpg"
}
```

### 2. Sản phẩm với nhiều variant

**products.json:**

```json
{
  "id": 9,
  "name": "New Product",
  "image": "images/new-product-main.jpg"
}
```

**product-variants.json:**

```json
[
  {
    "id": 13,
    "product_id": 9,
    "variant_name": "Size Large - Black",
    "price": 100,
    "quantity": 20,
    "image": "images/new-product-black-large.jpg"
  },
  {
    "id": 14,
    "product_id": 9,
    "variant_name": "Size Medium - White",
    "price": 90,
    "quantity": 15,
    "image": "images/new-product-white-medium.jpg"
  }
]
```

## 🖼️ CSS Đã Được Cập Nhật

### CSS cho Product Image

```css
.product-image {
  width: 100%;
  height: 200px;
  overflow: hidden;
}

.product-image img {
  width: 100%;
  height: 100%;
  object-fit: cover; /* Ảnh sẽ tự động cắt/vừa khít */
}
```

### CSS cho Product Detail Image

```css
.product-detail-image {
  width: 100%;
  height: 400px;
  overflow: hidden;
}

.product-detail-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
```

## ⚠️ Xử Lý Ảnh Lỗi

Code đã có cơ chế tự động fallback nếu ảnh không tải được:

```html
<img
  src="path/to/image.jpg"
  onerror="this.src='images/placeholder.jpg'; this.onerror=null;"
/>
```

- Nếu ảnh chính không tải được → tự động hiển thị placeholder
- Nếu placeholder cũng không có → hiển thị icon mặc định (Font Awesome)

## 📝 Danh Sách File Ảnh Cần Thêm

Dựa vào file `products.json`, bạn cần thêm các ảnh sau:

1. ✅ `images/macbook.jpg` - MacBook Pro 16
2. ❌ `images/iphone.jpg` - iPhone 15 Pro
3. ❌ `images/dell-xps.jpg` - Dell XPS 15
4. ❌ `images/galaxy-s24.jpg` - Samsung Galaxy S24 Ultra
5. ❌ `images/tshirt.jpg` - Men's Casual T-Shirt
6. ❌ `images/dress.jpg` - Women's Summer Dress
7. ❌ `images/js-book.jpg` - JavaScript Book
8. ❌ `images/toolset.jpg` - Garden Tool Set

**Lưu ý**: Hiện tại bạn đã có `macbook.jpg`, `macbook-gray.jpg`, `macbook-silver.jpg` - bạn có thể copy và đổi tên chúng cho các sản phẩm khác nếu chưa có ảnh thật.

## 🎨 Khuyến Nghị Cho Ảnh Sản Phẩm

1. **Kích thước**: ít nhất 400x400px
2. **Tỷ lệ**: 1:1 (vuông) hoặc 4:3
3. **Định dạng**: JPG (cho ảnh) hoặc PNG (cho ảnh có nền trong suốt)
4. **Chất lượng**: 70-85% JPG quality để tối ưu dung lượng
5. **Nền**: Nền trắng hoặc nền trong suốt cho ảnh sản phẩm

## 🚀 Quick Start

Để thêm ảnh nhanh:

1. Copy ảnh vào `susan-shop/images/`
2. Cập nhật đường dẫn trong `products.json`
3. Refresh trang web!

```bash
# Ví dụ:
cp ~/Documents/product-photo.jpg susan-shop/images/iphone.jpg
# Cập nhật products.json: "image": "images/iphone.jpg"
```

---

**Lưu ý**: Đảm bảo file ảnh tồn tại trước khi test website. Nếu không có ảnh, website sẽ tự động hiển thị icon placeholder.
