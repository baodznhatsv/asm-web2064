# Susan Shop - E-commerce Website

A full-featured e-commerce website built with vanilla JavaScript, following modern JavaScript practices and ES6+ features.

## 🛍️ Features

### Member Features

- **Product Browsing**: View all products with categories
- **Product Details**: Detailed view with variants, pricing, and availability
- **Shopping Cart**: Add products, update quantities, remove items
- **User Authentication**: Secure login and registration
- **Filter & Search**: Filter products by category and price range
- **Checkout Process**: Complete order placement with shipping information
- **Order Confirmation**: Thank you page after successful checkout

### Admin Features

- **Dashboard**: Overview of sales, orders, customers, and revenue
- **Category Management**: Create, edit, and delete product categories
- **Product Management**: Add, edit, and delete products with details
- **Order Management**: View and update order status
- **Customer Management**: View customer information and order history
- **Statistics**:
  - Total products and inventory
  - Total orders and revenue
  - Most ordered products
  - Low stock alerts

## 📁 Project Structure

```
susan-shop/
├── data/                    # JSON data files (simulating database)
│   ├── categories.json
│   ├── products.json
│   ├── product-variants.json
│   ├── orders.json
│   ├── order-details.json
│   └── users.json
├── scripts/                 # JavaScript modules
│   ├── api.js              # API utility for data fetching
│   ├── auth.js             # Authentication management
│   ├── cart.js             # Shopping cart management
│   ├── utils.js            # Utility functions
│   ├── main.js             # Home page logic
│   ├── products.js         # Products page logic
│   ├── product-detail.js   # Product detail page
│   ├── cart-page.js        # Shopping cart page
│   ├── checkout.js         # Checkout process
│   ├── login.js            # Login functionality
│   ├── register.js         # Registration functionality
│   └── thank-you.js        # Order confirmation
├── admin/                   # Admin panel
│   ├── index.html          # Admin dashboard
│   ├── categories.html     # Category management
│   ├── products.html       # Product management
│   ├── orders.html         # Order management
│   ├── customers.html      # Customer management
│   ├── statistics.html     # Statistics & reports
│   └── admin-*.js          # Admin page scripts
├── styles/                  # CSS files
│   ├── styles.css          # Main stylesheet
│   └── admin.css           # Admin panel styles
├── images/                  # Product images (placeholder)
├── index.html              # Home page
├── products.html           # Products listing
├── product-detail.html     # Product details
├── cart.html               # Shopping cart
├── checkout.html           # Checkout page
├── login.html              # Login page
├── register.html           # Registration page
└── thank-you.html          # Order confirmation
└── README.md               # This file
```

## 🗄️ Database Schema

The project uses JSON files to simulate a database with the following structure:

### Categories

- `id`: Category ID
- `name`: Category name
- `parent_id`: Parent category ID (null for main categories)

### Products

- `id`: Product ID
- `name`: Product name
- `cate_id`: Category ID
- `detail`: Product description
- `image`: Image filename

### Product Variants

- `id`: Variant ID
- `product_id`: Product ID
- `variant_name`: Variant name/description
- `price`: Price
- `quantity`: Stock quantity
- `image`: Variant image

### Orders

- `id`: Order ID
- `user_id`: Customer ID
- `created_date`: Order date
- `status`: Order status (pending, shipped, completed, cancelled)

### Order Details

- `id`: Order detail ID
- `order_id`: Order ID
- `product_id`: Product ID
- `quantity`: Quantity ordered
- `unit_price`: Unit price

### Users

- `id`: User ID
- `name`: User name
- `email`: Email address
- `phone`: Phone number
- `address`: Address
- `password`: Password (hashed in production)
- `role`: User role (member, admin)

## 🚀 Getting Started

### Prerequisites

- A modern web browser (Chrome, Firefox, Edge, Safari)
- A local web server (for testing)

### Installation

1. Clone or download the repository
2. Open the project in your code editor
3. Start a local web server:

#### Using Python

```bash
python -m http.server 8000
```

#### Using Node.js

```bash
npx http-server
```

#### Using PHP

```bash
php -S localhost:8000
```

4. Open your browser and navigate to `http://localhost:8000`

### Default Credentials

#### Admin Account

- Email: `john@example.com`
- Password: `password123`

#### Member Accounts

- Email: `jane@example.com` or `bob@example.com`
- Password: `password123`

## 💻 Technologies Used

### Frontend

- **HTML5**: Semantic markup
- **CSS3**: Modern styling with flexbox and grid
- **Vanilla JavaScript**: No framework dependencies
- **ES6+ Features**:
  - Arrow functions
  - Template literals
  - Destructuring
  - Spread operator
  - Classes and modules
  - Async/await
  - Fetch API

### Libraries

- **Font Awesome**: Icons
- **LocalStorage API**: Client-side data storage
- **Fetch API**: HTTP requests for data

## 📝 Key Features Implementation

### Module System (ES6)

All JavaScript is organized into modules using ES6 import/export:

- Modular architecture
- Code reusability
- Better maintainability

### Local Storage Management

- Shopping cart persists across sessions
- User authentication state management
- Order history storage

### Responsive Design

- Mobile-first approach
- Flexible grid layouts
- Touch-friendly interface

### Modern JavaScript Practices

- Arrow functions for concise syntax
- Template literals for string interpolation
- Async/await for asynchronous operations
- Classes for object-oriented code
- Destructuring for clean variable assignment

## 🎨 Design Philosophy

- **Clean UI**: Minimalist design with focus on usability
- **User Experience**: Intuitive navigation and clear feedback
- **Performance**: Optimized code and efficient data handling
- **Accessibility**: Semantic HTML and proper ARIA labels

## 📋 Feature Checklist

### ✅ Completed Features

#### Member Side

- [x] Product listing with categories
- [x] Product detail view with variants
- [x] Shopping cart functionality
- [x] User registration
- [x] User login/logout
- [x] Product filtering by category and price
- [x] Checkout process
- [x] Order confirmation page

#### Admin Side

- [x] Dashboard with statistics
- [x] Category management (CRUD)
- [x] Product management (CRUD)
- [x] Order management with status updates
- [x] Customer management
- [x] Statistics and reporting

## 🔒 Security Considerations

- Input validation
- Email and phone validation
- Password requirements
- Authentication checks for protected pages
- Admin authorization checks

## 🚧 Future Enhancements

- Payment gateway integration
- Email notifications
- Product reviews and ratings
- Wishlist functionality
- Advanced search
- Product recommendations
- Social media integration
- Multi-language support

## 📄 License

This project is created for educational purposes as part of the WEB2064 course.

## 👥 Author

Trần Ngọc Bảo - PD11383

## 📞 Contact

For questions or support, please contact:

- Email: info@susanshop.com
- Phone: +1 234 567 8900

---

**Note**: This is a demonstration project using client-side JavaScript and JSON files for data storage. In a production environment, implement proper backend services, database connections, and security measures.
