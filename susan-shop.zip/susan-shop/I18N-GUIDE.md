# Hướng Dẫn Sử Dụng Tính Năng Đa Ngôn Ngữ (I18n)

## 🌍 Tính Năng Đã Thêm

Website Susan Shop hiện đã hỗ trợ đa ngôn ngữ với 2 ngôn ngữ:

- 🇻🇳 **Tiếng Việt (VN)** - Ngôn ngữ mặc định
- 🇬🇧 **English (EN)**

## 📁 Các File Đã Tạo

### 1. `scripts/translations.js`

File này chứa tất cả các văn bản cho cả 2 ngôn ngữ. Cấu trúc:

```javascript
export const translations = {
  en: {
    "nav.home": "Home",
    "nav.products": "Products",
    // ...
  },
  vn: {
    "nav.home": "Trang Chủ",
    "nav.products": "Sản Phẩm",
    // ...
  },
};
```

### 2. `scripts/i18n.js`

File này quản lý việc chuyển đổi ngôn ngữ và cập nhật nội dung.

## 🚀 Cách Sử Dụng

### 1. Thêm Văn Bản Mới

Để thêm văn bản mới, mở file `scripts/translations.js` và thêm key vào cả 2 object `en` và `vn`:

```javascript
export const translations = {
  en: {
    "my.new.key": "My new text in English",
    // ...
  },
  vn: {
    "my.new.key": "Văn bản mới của tôi",
    // ...
  },
};
```

### 2. Sử Dụng Trong HTML

Thêm thuộc tính `data-i18n` vào các phần tử HTML:

```html
<h1 data-i18n="hero.title">Welcome to Susan Shop</h1>
<button data-i18n="hero.button">Shop Now</button>
```

### 3. Sử Dụng Trong JavaScript

Import và sử dụng i18n trong file JavaScript:

```javascript
import i18n from "./i18n.js";

// Lấy văn bản đã dịch
const text = i18n.t("nav.home");

// Hiển thị message
showMessage(i18n.t("message.loginSuccess"), "success");
```

### 4. Thêm Select Ngôn Ngữ Mới

Nếu muốn thêm ngôn ngữ mới, ví dụ tiếng Trung:

1. Thêm object `zh` vào file `translations.js`:

```javascript
export const translations = {
  en: {
    /* ... */
  },
  vn: {
    /* ... */
  },
  zh: {
    "nav.home": "首页",
    // ...
  },
};
```

2. Cập nhật function `getLanguageSwitcherHTML()` trong file `i18n.js` để thêm option mới.

## 🔧 Tích Hợp Vào Các Trang Khác

Để tích hợp vào các trang còn lại:

### Bước 1: Thêm i18n.js vào HTML

Thêm script import vào `</body>` của mỗi HTML:

```html
<script type="module" src="scripts/i18n.js"></script>
```

### Bước 2: Thêm data-i18n vào các phần tử

```html
<h1 data-i18n="page.title">Page Title</h1>
<p data-i18n="page.description">Description</p>
```

### Bước 3: Sử dụng trong JavaScript

```javascript
import i18n from "./i18n.js";

// Sử dụng trong code
showMessage(i18n.t("message.success"));
```

## 📋 Các Trang Đã Được Cập Nhật

✅ index.html - Trang chủ  
✅ login.html - Trang đăng nhập  
⏳ Các trang khác đang chờ cập nhật

## 🎨 Nút Đổi Ngôn Ngữ

Nút đổi ngôn ngữ được tự động thêm vào:

- Navigation bar (Menu chính)
- Admin navigation (Menu quản trị)

Nó xuất hiện dưới dạng dropdown select cho phép chọn Tiếng Việt hoặc English.

## 💾 Lưu Trữ Ngôn Ngữ

Ngôn ngữ đã chọn được lưu vào `localStorage` với key `susan_shop_lang`, vì vậy lần tải tiếp theo sẽ giữ nguyên ngôn ngữ đã chọn.

## 🔄 Sự Kiện Language Changed

Khi người dùng đổi ngôn ngữ, một custom event `languageChanged` được dispatch. Bạn có thể lắng nghe event này để cập nhật nội dung động:

```javascript
document.addEventListener("languageChanged", (e) => {
  console.log("Language changed to:", e.detail.language);
  // Cập nhật nội dung động ở đây
});
```

## 📝 Ghi Chú

- Tất cả văn bản trong HTML nên có thuộc tính `data-i18n`
- Văn bản trong HTML chỉ là placeholder, sẽ được thay thế khi i18n được khởi tạo
- Luôn đảm bảo có cả bản dịch EN và VN cho mỗi key mới

## 🎯 Ví Dụ Hoàn Chỉnh

### File HTML

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>My Page</title>
    <link rel="stylesheet" href="styles.css" />
  </head>
  <body>
    <nav>
      <h1 data-i18n="app.title">My App</h1>
      <button data-i18n="app.button">Click Me</button>
    </nav>

    <script type="module" src="scripts/i18n.js"></script>
    <script type="module" src="scripts/main.js"></script>
  </body>
</html>
```

### File JavaScript

```javascript
import i18n from "./i18n.js";

// Sử dụng i18n
console.log(i18n.t("app.title")); // Output: "My App" or "Ứng Dụng Của Tôi"

// Listen for language changes
document.addEventListener("languageChanged", () => {
  console.log("Language changed!");
});
```

### File translations.js

```javascript
export const translations = {
  en: {
    "app.title": "My App",
    "app.button": "Click Me",
  },
  vn: {
    "app.title": "Ứng Dụng Của Tôi",
    "app.button": "Nhấn Tôi",
  },
};
```

## 🚀 Sử Dụng Ngay

1. Mở website
2. Click vào dropdown ngôn ngữ ở navigation (🇻🇳 Tiếng Việt / 🇬🇧 English)
3. Chọn ngôn ngữ mong muốn
4. Toàn bộ nội dung sẽ được cập nhật ngay lập tức

---

**Lưu ý**: Tính năng này cần được áp dụng tương tự cho các trang còn lại (products, cart, checkout, register, thank-you.html và các trang admin).
